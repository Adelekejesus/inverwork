# 🚀 Guía de instalación — InverWork · Inverfin Holding
## Firebase (base de datos) + Vercel (publicación)

---

## PASO 1 — Crear proyecto en Firebase (5 min)

1. Ve a **https://console.firebase.google.com**
2. Haz clic en **"Crear un proyecto"**
3. Nombre: `inverwork-inverfin` → Continuar
4. Desactiva Google Analytics (no es necesario) → Crear proyecto

### Activar Realtime Database
5. En el menú izquierdo: **Build → Realtime Database**
6. Clic en **"Create Database"**
7. Selecciona la región más cercana (ej. `us-central1`)
8. En las reglas de seguridad, selecciona **"Start in test mode"** → Enable

### Obtener las credenciales
9. En el menú izquierdo: ⚙️ **Project Settings**
10. Baja hasta **"Your apps"** → clic en el ícono `</>`  (Web)
11. App nickname: `inverwork` → Register app
12. **Copia el objeto `firebaseConfig`** — lo necesitas en el paso 3

Ejemplo de lo que verás:
```javascript
const firebaseConfig = {
  apiKey: "AIzaSy...",
  authDomain: "inverwork-inverfin.firebaseapp.com",
  databaseURL: "https://inverwork-inverfin-default-rtdb.firebaseio.com",
  projectId: "inverwork-inverfin",
  storageBucket: "inverwork-inverfin.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abc123"
};
```

---

## PASO 2 — Configurar reglas de Firebase

En **Realtime Database → Rules**, reemplaza las reglas con esto:
```json
{
  "rules": {
    ".read": true,
    ".write": true
  }
}
```
Clic en **Publish**

> ⚠️ Estas reglas son para uso interno. Si quieres más seguridad en el futuro, avísanos y las configuramos con autenticación.

---

## PASO 3 — Pegar las credenciales en el código

1. Abre el archivo `index.html`
2. Busca esta sección (está cerca del inicio):

```javascript
const firebaseConfig = {
  apiKey:            "TU_API_KEY",
  authDomain:        "TU_PROYECTO.firebaseapp.com",
  databaseURL:       "https://TU_PROYECTO-default-rtdb.firebaseio.com",
  ...
```

3. **Reemplaza** cada valor con los que copiaste en el paso 1
4. Guarda el archivo

---

## PASO 4 — Publicar en Vercel (3 min)

### Opción A — Sin cuenta GitHub (más rápido)

1. Ve a **https://vercel.com**
2. Crea una cuenta gratuita (con email o Google)
3. En el dashboard, clic en **"Add New → Project"**
4. Selecciona **"Deploy from your computer"** o usa Vercel CLI:

```bash
# Instalar Vercel CLI
npm install -g vercel

# En la carpeta del proyecto
vercel

# Sigue las instrucciones:
# - Set up and deploy? Y
# - Which scope? (tu cuenta)
# - Link to existing project? N
# - Project name: inverwork
# - Directory: ./  (o donde esté el index.html)
```

5. Al terminar te da una URL como: `https://inverwork.vercel.app`

### Opción B — Con GitHub (recomendado para futuras actualizaciones)

1. Crea repositorio en **github.com** (puede ser privado)
2. Sube la carpeta del proyecto
3. En Vercel → Import Git Repository → selecciona el repo
4. Deploy → listo

---

## PASO 5 — Compartir con el equipo

Envía a todos la URL de Vercel, por ejemplo:
```
https://inverwork-inverfin.vercel.app
```

### Credenciales de acceso:
| Rol | Usuario | Contraseña |
|-----|---------|------------|
| Admin | `admin` | `inverfin2025` |
| Gerencia | Registro con código: `inverfin2025` | — |
| Empleados | Registro libre | — |

> 💡 Cambia la contraseña del admin en el código antes de publicar.

---

## RESUMEN VISUAL

```
Tu equipo
   │
   ▼
[Navegador] → vercel.app/inverwork
                    │
                    ▼
             [Firebase DB] ← datos en tiempo real
                    │
                    ▼
             [Admin descarga Excel]
```

---

## ¿Algo no funciona?

- **Pantalla de carga infinita**: Verifica que `databaseURL` en firebaseConfig sea correcto
- **Error de permisos**: Revisa las reglas de Firebase (Paso 2)
- **No se guardan datos**: Asegúrate de que Realtime Database esté activado (no Firestore)

---

Preparado por InverWork · Inverfin Holding
